package com.kisaa.www.footballschedule.model

data class League (
    val leagueName: String?,
    val leagueId: String?
)