package com.kisaa.www.footballschedule.response

import com.kisaa.www.footballschedule.model.Team

data class TeamResponse (
    val teams: List<Team>
)